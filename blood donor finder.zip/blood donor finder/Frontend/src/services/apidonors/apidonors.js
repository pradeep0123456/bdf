import axios from 'axios'
import apiurl from '../apiendpoint/apienspoint';
import { gettoken } from '../token/token';
export const apiregisterdonor=async(datas)=>{
    const res= await axios.post(`${apiurl()}/api/apiregisterdonor`,datas);
    return res.data;
}
export const apilogindonor=async(datas)=>{
    const res= await axios.post(`${apiurl()}/api/apilogindonor`,datas);
    return res.data;
}
export const apigetdonor=async()=>{
    const res= await axios.get(`${apiurl()}/api/apigetdonor`,{ headers: {"Authorization" : `Bearer ${gettoken()}`}});
    return res.data;
}
export const apiupdatedonor=async(id,datas)=>{
    const res= await axios.put(`${apiurl()}/api/apiupdatedonor`,datas,{params:{_id:id}, headers: {"Authorization" : `Bearer ${gettoken()}`}});
    return res.data;
}
export const apideletedonor=async(id)=>{
    const res= await axios.post(`${apiurl()}/api/apideletedonor`,{_id:id},{headers: {"Authorization" : `Bearer ${gettoken()}`}});
    return res.data;
}
export const apifinddonor=async(datas)=>{
    const res= await axios.post(`${apiurl()}/api/apifinddonor`,datas);
    return res.data;
}