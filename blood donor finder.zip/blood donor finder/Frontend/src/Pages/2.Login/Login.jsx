import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { apilogindonor } from '../../services/apidonors/apidonors';
import toast from 'react-hot-toast';
import { settoken } from '../../services/token/token';

const LoginForm = () => {
  const navigate=useNavigate()
  const [formdata,setformdata]=useState({})

  const onchange=(e)=>{
   setformdata({...formdata,[e.target.name]:e.target.value})
  }
  const handleSubmit = async(e) => {
    e.preventDefault();
    const res=await apilogindonor(formdata)
    if(res.status=='Success'){
    setformdata({})
    toast.success("Sucessfully login")
    settoken(res.token)
    navigate('/profile')
    }
    else{
      toast.error(res.status)
    }
  };

  return (
    <div className="flex justify-center items-center h-screen overflow-hidden"> {/* Added overflow-hidden class */}
      <form onSubmit={handleSubmit} className="bg-gray-100 shadow-md rounded px-8 pt-6 pb-8 mb-4  h-3/5  sm:w-2/5 md:w-1/2 lg:w-1/3 xl:w-1/3">
        <div className="text-center text-green-500 text-3xl mb-4">
          <h1>Login</h1>
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
            Email
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="email"
            type="email"
            placeholder="Email"
            name="email"
            onChange={onchange}
          />
        </div>
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
            Password
          </label>
          <div className="flex items-center">
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="password"
              type="date"
              placeholder="Date of Birth"
              name="dob"
              onChange={onchange}
            />
            
            {/* Calendar symbol */}
          </div>
        </div>
        <div className="flex items-center justify-center mt-8">
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-1/3"
            type="submit">
            Log In
          </button>
        </div>
        <div className='text-center pt-4'>
           <p>don't have account <a href='/register' className='text-blue-500 underline hover:text-green-700'>Register</a></p>
        </div>
      </form>
    </div>
  );
};

export default LoginForm;
