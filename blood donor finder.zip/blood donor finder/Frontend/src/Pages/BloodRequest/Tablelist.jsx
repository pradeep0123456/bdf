

export default function Tablelist({blooddata}) {
  return (
    <div>
       <table class="border-collapse border border-slate-400 ...">
  <thead>
    <tr>
      <th class="border border-slate-300 p-3">Full Name</th>
      <th class="border border-slate-300 p-3">Email</th>
      <th class="border border-slate-300 p-3">Mobile Number</th>
    </tr>
  </thead>
  <tbody>
    {blooddata.map((data,index)=><tr>
      <td class="border border-slate-300 p-3">{data.fullname}</td>
      <td class="border border-slate-300 p-3">{data.email}</td>
      <td class="border border-slate-300 p-3">{data.phonenumber}</td>
    </tr>
    )}
  
  </tbody>
</table>
    </div>
  )
}
