import React, { useState, useEffect } from 'react';
import { apideletedonor, apigetdonor, apiupdatedonor } from '../../services/apidonors/apidonors';
import { getalladdress } from '../../services/apiaddress/apiaddress';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';



const Profile = () => {
  const navigate=useNavigate()
  const [formdata,setformdata]=useState({})

  const [selectdata,setselectdata]=useState({})
  useEffect(() => {
    // Fetch user details from backend upon component mount
    fetchUserDetails();
  }, []);

  const fetchUserDetails = async () => {
    try {
      // Make API request to fetch user details
      const response = await apigetdonor();
      setformdata(response);
      getaddress(response?.district)
      getvillage(response?.taluk)
    } catch (error) {
      console.error('Error fetching user details:', error);
    }
  };
  const getaddress=async(e)=>{
    console.log(e.target.value)
    const res= await getalladdress()
    const dis=res.filter(res=>res.District==e.target.value)
    setselectdata({...selectdata,"taluk":dis.map(res=>res.Taluk_Name)})
 
   }
   const getvillage=async(e)=>{
     console.log(e.target.value)
     const res= await getalladdress()
     const dis=res.filter(res=>res.Taluk_Name==e.target.value)
     setselectdata({...selectdata,"village":dis[0].Villages})
  
    }
 

  const onchange=(e)=>{
    setformdata({...formdata,[e.target.name]:e.target.value})
   }
   const updateprofile = async(e) => {
     e.preventDefault();
     const res=await apiupdatedonor(formdata?.id,formdata)
 
     toast.success("Sucessfully profile updated")
  
   };

  const handleDelete = async () => {
    try {
      // Make API request to delete user details
      await apideletedonor(formdata?._id);
      toast.success("Sucessfully profile deleted")
      navigate('/');
    } catch (error) {
      console.error('Error deleting user details:', error);
    }
  };

  return (
    <div className="max-w-[45rem] mx-auto px-4 py-40">
      <h1 className="text-3xl font-bold mb-4">User Profile</h1>
      <div className="mb-4">
        <form onSubmit={updateprofile}>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="fullName">
            Full Name
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="fullName"
            type="text"
            value={formdata?.fullname}
            placeholder="Full Name"
           name="fullname"
            onChange={onchange}
            required
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="dob">
            Date of Birth
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="dob"
            type="date"
            name='dob'
            value={formdata?.dob}
            onChange={onchange}
            required
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
            Email
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="email"
            type="email"
            placeholder="Email"
            name='email'
            value={formdata?.email}
            onChange={onchange}
            required
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="phoneNo">
            Phone Number
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="phoneNo"
            type="number"
            placeholder="Phone Number"
            name='phonenumber'
            value={formdata?.phonenumber}
            onChange={onchange}
            required
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="bloodGroup">
            Blood Group
          </label>
          <select
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="bloodGroup"
            name="bloodgroup"
            onChange={onchange}
            value={formdata?.bloodgroup}
            required
          >
            <option value="">Select Blood Group</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
          </select>
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="bloodLocation">
            Address
          </label>
          <div className="grid grid-cols-2 gap-4">
          <select
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              name="state"
             
              onChange={onchange}
             
            >
              <option value="">Select State</option>
              <option>Tamil Nadu</option>
              
            </select>
            <select
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              name="district"
             
              onChange={(e)=>{onchange(e);getaddress(e)}}
             
            >
              <option value="">Select District</option>
              <option>Cuddalore</option>
              
            </select>
        
            <select
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              name="taluk"
              value={formdata?.taluk}
             onChange={(e)=>{onchange(e);getvillage(e)}}
             
            >
              <option value="">Select Taluk</option>
             {selectdata?.taluk?.map((data,index)=>
              <option key={index}>{data}</option>
              )}
            </select>
            <select
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              name="village"
              value={formdata?.village}
              onChange={onchange}
              
            >
              <option value="">Select Village</option>
              {selectdata?.village?.map((data,index)=>
              <option key={index}>{data}</option>
              )}
            </select>
          </div>
        </div>
        <div className="flex space-x-4">
        <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          type='submit'>
          Update Profile
        </button>
        <button className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          onClick={handleDelete} type='button'>
          Delete Account
        </button>
      </div>
        </form>
      
      </div>
     
    </div>
  );
};

export default Profile;
