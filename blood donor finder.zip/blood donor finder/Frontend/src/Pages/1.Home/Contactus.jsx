

const Contactus = () => {
  return (
    <div className="max-w-full w-full mx-auto">
    <div className="py-20 flex justify-center items-center text-center">
      <h1 className=" text-5xl font-bold text-green-500 pt-5">Contact Us</h1>
     
    </div>
    </div>
  )
}

export default Contactus
