import { BrowserRouter as Router,Routes,Route } from 'react-router-dom'
import './App.css'
import { Toaster } from 'react-hot-toast';
import Navbar from './Components/Header/Navbar'
import Home from './Pages/1.Home/Home'
import Login from './Pages/2.Login/Login'
import Register from './Pages/3.Register/Register'
import Bloodrequest from './Pages/BloodRequest/Bloodrequest'
import Aboutus from './Pages/1.Home/Aboutus'
import Contactus from './Pages/1.Home/Contactus'
import Profile from './Pages/Profile/Profile';


function App() {
  return (
    <div>
      <Router>
       <Navbar/>

       <Routes>
          <Route  path='/' element={<Home/>}/>
          <Route  path='/aboutus' element={<Aboutus/>}/>
          <Route  path='/login' element={<Login/>}/>
          <Route  path='/register' element={<Register/>}/>
          <Route  path='/bloodrequest' element={<Bloodrequest/>}/>
          <Route  path='/contactus' element={<Contactus/>}/>
          <Route path='/profile' element={<Profile/>}/>
       </Routes>
     </Router>
     <Toaster position="top-right" reverseOrder={false}/>
    </div>
  )
}

export default App
