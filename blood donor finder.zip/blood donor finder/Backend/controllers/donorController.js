

import { Donors } from '../models/donorModel.js'
import sendMail from '../services/mailService.js'
export const finddonor= async (req, res, next) => {
    try {
        const {state,district,bloodgroup,taluk}=req.body
    
      const resdata = await Donors.find({bloodgroup,state,district,taluk})
      sendMail(resdata.map(d=>d.email),req.body)
      res.send(resdata)
    } catch (err) {
      console.error(err)
    }
  }

export const getdonor= async (req, res, next) => {
  try {
    const {email}=req.user
    const resdata = await Donors.findOne({email})
    res.send(resdata)
  } catch (err) {
    console.error(err)
  }
}


export const updatedonor= async (req, res, next) => {
  try {
   
   
    const resdata = await Donors.findOneAndUpdate({ _id:req.body._id }, req.body, { new: true })
    res.send(resdata)
  } catch (err) {
    console.error(err)
  }
}
export const deletedonor = async (req, res, next) => {
  try {
    const resdata = await Donors.deleteOne({ _id :req.body._id})
    res.send(resdata)
  } catch (err) {
    console.error(err)
  }
}