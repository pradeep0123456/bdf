
import jwt from 'jsonwebtoken'
import { Donors } from '../models/donorModel.js'
export const Login = async (req, res, next) => {
  try {
    const { email, dob } = req.body
    const resdata = await Donors.findOne({ email, Status: 'Active' })
    if (!resdata) {
      return res.send({ status: 'Invalid email or password' })
    }
    console.log(dob,resdata.dob)
    if (dob ===  resdata.dob) {
      const token =jwt.sign({ _id: resdata._id, fullname: resdata.fullname, email: resdata.email, Role: resdata.Role }, "TOKENSECRET");
      res.send({ status: 'Success', token })
    } else {
      res.send({ status: 'Invalid email or password' })
    }
  } catch (err) {
    console.error(err)
  }
}