import nodemailer from 'nodemailer'
const sendMail = (mails, data) => {
    console.log(mails, data)
    const username = 'developer2.git@gmail.com';
    const password = 'tezg sxgb amui hewv';
try{
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      secure: false,
      auth: {
        user: username,
        pass:password
      },
      tls: {
        rejectUnauthorized: false
      }
    })
   
    const mailOptions = {
      from: username,
      to: mails,
      subject: `BLOOD DONOR FINDER - need ${data.bloodgroup} blood group`,
      html: `
      <ul>
        <li>Full Name: ${data.fullname}</li>
        <li>Email: ${data.email}</li>
        <li>Mobile Number: ${data.phonenumber}</li>
        <li>Needed Bloodgroup: ${data.bloodgroup}</li>
        <li>Hospital Name: ${data.hospitalname}</li>
      
      </ul>
    `
    }

    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log(error)
      } else {
        console.log('Email Sent')
        return 'ok'
      }
    })
}
catch(err){
    console.log(err)
}

}
export default sendMail