import express from 'express'
import { registerdonor } from '../controllers/registerContoller.js'
import { Login } from '../controllers/loginController.js'
import { deletedonor, finddonor, getdonor, updatedonor } from '../controllers/donorController.js'
import authMiddleware from '../middlewares/authMiddleware.js'
const apiRouter = express.Router()
apiRouter.post('/apiregisterdonor', registerdonor)
apiRouter.post('/apilogindonor', Login)
//donors
apiRouter.get('/apigetdonor',authMiddleware(['donor']), getdonor)
apiRouter.put('/apiupdatedonor',authMiddleware(['donor']), updatedonor)
apiRouter.post('/apideletedonor',authMiddleware(['donor']), deletedonor)
apiRouter.post('/apifinddonor', finddonor)
export default apiRouter